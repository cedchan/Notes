## Uniform Distribution

Intuitively, a random variable $U$ has the uniform distribution on $(a, b)$ if $U$ is a "completely random" number between $a$ and $b$. More precisely, that means that the PDF of $U$ is constant over the interval $(a, b)$, which is also its support.

>[!definition]
>A continuous random variable $U$ has the **Uniform distribution** on $(a, b)$ if its PDF is
>$$f(x)=\begin{cases}\displaystyle\frac1{b-a} & \text{if }a<x<b \\ 0 & \text{o.w.}\end{cases}$$
>We write $U\sim{\rm Unif}(a,b)$.
>
>The **standard uniform distribution** is ${\rm Unif}(0,1)$.

We can easily find that the CDF is
$$F(x)=\begin{cases}0& x<a \\
\displaystyle\frac{x-a}{b-a}&a<x<b\\
1 & x>b
\end{cases}$$

For the standard uniform distribution, it's even simpler:
- $f(x)=1$ for $0<x<1$ and $0$ otherwise
- $F(x)=x$ for $0<x<1$ and $0$ or $1$ otherwise

### Expectation and Variance

>[!summary]
>$$\begin{align}
>\mathbb E(w)&=\frac{a+b}2\\
>{\rm Var}(w)&=\frac{(b-a)^2}{12}
>\end{align}$$

With simple integration, we find for $U\sim{\rm Unif}(0,1)$ that $\mathbb E(U)=\frac{1}2$. Using LOTUS we find ${\rm Var}(U)=\frac1{12}$.

We could use integrals and the definition of expectation to find the mean and variance in the general case, but it's easier to use a location-scale transformation. 

If $U\sim{\rm Unif}(0,1)$ then let $W=a+(b-a)U$. We show that $W\sim{\rm Unif}(a,b)$ by showing that it has the correct CDF.
$$\begin{align}
F_W(w)&=\Pr(W\leq w) \\
&=\Pr(a+(b-a)U\leq w) \\
&=P\left(U\leq\frac{w-a}{b-a}\right) \\
&=F_U\left(\frac{w-a}{b-a}\right)\\
F_W(w)&=\begin{cases}
0 & w\leq a \\
\displaystyle\frac{w-a}{b-a}&a<w<b\\
1 & w\geq b
\end{cases}\\
&\tag*{$\square$}
\end{align}$$

Then, using linearity of expectation, we can say 
$$\mathbb E(W)=a+(b-a)\mathbb E(U)$$
We know $\mathbb E(U)=\frac12$, so
$$\mathbb E(W)=\frac{a+b}2$$
Similarly for variance,
$${\rm Var}(W)=(b-a)^2{\rm Var}(U)=\frac{(b-a)^2}{12}$$

### Universality of the Uniform

We can start with $U\sim{\rm Unif}(0,1)$ and transform $U$ into a random variable $X$ with any continuous distribution we want. This is also called **inverse transform sampling**.

Conversely, we can start with a continuous random variable $X$ and transform $X$ into a ${\rm Unif}(0, 1)$ random variable $U$. This is also called the **probability integral transform**. This is useful in statistical tests, etc.

>[!theorem]
>Let $F$ be a continuous<sup>1</sup> CDF that is strictly increasing on the support of the distribution. (Thus, $F$ is a bijection from the support to $(0,1)$ and has an inverse function $F^{-1}: (0,1)\to\mathbb R$.)
>
>If $U\sim{\rm Unif}(0,1)$, then $X=F^{-1}(U)$ is a random variable with CDF $F$.
>
><sup><small></sup>[1]: Without this assumption, we can transform the standard uniform distribution into a discrete distribution, but just not vice versa.</small>

**Proof.** 
- Let $F(x)$ be the CDF of $F$. We show that our derived CDF $F_X(x)=F(X)$.
- By definition, the CDF of $X$ is the function that maps $x\in \mathbb R$ to $\Pr(X\leq x)$. 
- $\Pr(X\le x)=\Pr(F^{-1}(U)\le x)$
- Applying $F$ to both sides of the equation (since $F$ is increasing), we have $$\Pr(F(F^{-1}(U)\le F(x))$$
- Since we know $U\sim{\rm Unif}(0,1)$, $\Pr(U\le F(x))=F(x)$.
$$\tag*{$\square$}$$

>**Example.** Universality with Rayleigh.
>
>The Rayleigh distribution has CDF $F(x)=1-e^{-x^2/2}, x>0$. Starting with $U\sim{\rm Unif}(0,1)$, how can we generate a random variable with the Rayleigh distribution?
>
>>[!solution]-
>>First, find $F^{-1}$:
>>- Let $u=F(x)=1-e^{-x^2/2}$ for $x>0$
>>- Solve for $x$ in terms of $u$: $x=\sqrt{-2\ln(1-u)}$
>>
>>Thus, $F^{-1}(U)=\sqrt{-2\ln(1-U)}$ has the Rayleigh distribution.

### Backward Direction

>[!theorem]
>
>Let $X$ be a random variable with a continuous CDF $F$ that is strictly increasing on the support of the distribution.
>
>Then, the random variable $F(X)$ has the ${\rm Unif(0,1)}$ distribution.

Some review
- $F:\mathbb R\to[0,1]$
- $F(x)$ is the probability that $X\le x, x\in\mathbb R$
- But $F(X)$ is not the probability that $X\le X$. Rather, it is meant as a function of a random variable.

>**Example.** 